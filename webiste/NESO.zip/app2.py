from flask import Flask, render_template, request
import paho.mqtt.client as mqtt

app = Flask(__name__)

# Konfigurasi MQTT broker
mqtt_broker = "192.168.43.116"
mqtt_port = 1883
topic1 = "topic/perangkat1"
topic2 = "topic/perangkat2"
topic3 = "topic/perangkat3"


def on_publish(client, userdata, mid):
    print("Pesan berhasil terkirim")

# Inisialisasi MQTT client
mqtt_client = mqtt.Client()
mqtt_client.on_publish = on_publish
mqtt_client.connect(mqtt_broker, mqtt_port)

@app.route('/')
def index():
    return render_template('home.html')

@app.route('/control', methods=['GET', 'POST'])
def control():
    if request.method == 'POST':
        status1 = request.form.get('status1')
        status2 = request.form.get('status2')
        status3 = request.form.get('status3')

        if status1 == 'on':
            mqtt_client.publish(topic1, 'ON')
        elif status1 == 'off':
            mqtt_client.publish(topic1, 'OFF')

        if status2 == 'on':
            mqtt_client.publish(topic3, 'ON2')
        elif status2 == 'off':
            mqtt_client.publish(topic3, 'OFF2')

        if status3 == 'on':
            mqtt_client.publish(topic3, 'ON3')
        elif status3 == 'off':
            mqtt_client.publish(topic3, 'OFF3')

    return render_template('control.html')

if __name__ == '__main__':
    app.run(debug=True)
